﻿namespace Code_First;

public class Example
{
    public int Id { get; set; }
    public string Value { get; set; }
}