﻿// See https://aka.ms/new-console-template for more information

using Code_First;
using Microsoft.EntityFrameworkCore;

class main
{
    public static void Main(string[] args){}
}

public partial class ExampleContext : DbContext
{
    public ExampleContext()
    {

    }

    public ExampleContext(DbContextOptions<ExampleContext> options)
        : base(options)
    {

    }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
    {
        optionsBuilder.UseMySQL(@"Server=127.0.0.1;uid=root;pwd=insy;database=demo");

    }

    public virtual DbSet<Example> Examples { get; set; }
    public virtual DbSet<Example2> Examples2 { get; set; }
}